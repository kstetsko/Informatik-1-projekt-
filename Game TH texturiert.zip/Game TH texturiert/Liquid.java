abstract class Liquid {

    double x, y, w, h;
    int r, g, b;

    Liquid(double x, double y, double w, double h, int r, int g, int b) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.r = r;
        this.g = g;
        this.b = b;
    }

    abstract boolean canPlayerEnter(Player player);

    public void draw() {
        Draw.setColor(r, g, b);
        Draw.filledRect((int)x, (int)y, (int)w, (int)h);
    }

    public void handlePlayer(Player p) {
        if (!intersects(p)) return;

        if (!canPlayerEnter(p)) {
            p.requestRespawn();
        }
    }

    private boolean intersects(Player p) {
        return p.x < x + w &&
               p.x + p.w > x &&
               p.y < y + h &&
               p.y + p.h > y;
    }
}
