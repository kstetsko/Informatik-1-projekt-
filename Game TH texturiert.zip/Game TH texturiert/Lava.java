public class Lava extends Liquid {

    public Lava(double x, double y, double w, double h) {
        super(x, y, w, h, 255, 0, 0);
    }

    @Override
    boolean canPlayerEnter(Player player) {
        return !player.isPlayer1();
    }
}
