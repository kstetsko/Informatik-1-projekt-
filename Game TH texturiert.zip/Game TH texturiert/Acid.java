public class Acid extends Liquid {

    public Acid(double x, double y, double w, double h) {
        super(x, y, w, h, 0, 255, 0);
    }

    @Override
    boolean canPlayerEnter(Player player) {
        return false;
    }
}
