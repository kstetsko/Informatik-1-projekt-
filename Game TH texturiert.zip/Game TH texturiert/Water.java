public class Water extends Liquid {

    public Water(double x, double y, double w, double h) {
        super(x, y, w, h, 0, 0, 255);
    }

    @Override
    boolean canPlayerEnter(Player player) {
        return player.isPlayer1();
    }
}
