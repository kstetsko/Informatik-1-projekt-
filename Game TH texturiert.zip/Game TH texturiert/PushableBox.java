public class PushableBox {
    double x, y;
    double w = 40, h = 40; // = player size

    double vx = 0, vy = 0; // velocity

    double speed = 300; // pixels per sec, pushing
    double g = 900; // gravity, pixels per sec^2

    boolean onGround = false;

    public PushableBox(double x, double y) {
        this.x = x;
        this.y = y;
    }

    // check if the box is on the ground
    public void setOnGround(boolean onGround) {
        this.onGround = onGround;
        if (onGround) {
            this.vy = 0;
        }
    }

    // check if player is pushing th box from left or right
    public void pushBox(Player player) {
        // from the left
        if (player.x + player.w <= this.x && player.vx > 0) {
            this.vx = player.vx * 0.5; // half player's velocity
        }
        // from the right
        else if (player.x >= this.x + this.w && player.vx < 0) {
            this.vx = player.vx * 0.5;
        }
    }

    // apply gravity and update position
    public void update(double dt) {
        // apply gravity
        if (!onGround) {
            vy += g * dt;
        } else {
            vx *= 0.80; // box slows down faster
            if (Math.abs(vx) < 5) {
                vx = 0;
            }
        }

        // update position
        x += vx * dt;
        y += vy * dt;

        // reset onGround flag
        onGround = false;
    }

    public void draw() {
        Draw.setColor(180, 140, 100);
        Draw.filledRect((int) x, (int) y, (int) w, (int) h);
    }

    // check if the box intersects with something
    public static boolean intersects(PushableBox box, Platform platform) {
        return box.x < platform.x + platform.w &&
                box.x + box.w > platform.x &&
                box.y < platform.y + platform.h &&
                box.y + box.h > platform.y;
    }

    public static boolean intersects(PushableBox box, PushableBox other) {
        return box.x < other.x + other.w &&
                box.x + box.w > other.x &&
                box.y < other.y + other.h &&
                box.y + box.h > other.y;
    }

    public static boolean intersects(PushableBox box, Player player) {
        return box.x < player.x + player.w &&
                box.x + box.w > player.x &&
                box.y < player.y + player.h &&
                box.y + box.h > player.y;
    }
}