public class Platform {
    double x, y, w, h;
    private static int[][] texture;
    static {
    texture = Draw.loadImage("assets/wooden_tiles00.png");
    if (texture == null) {
        System.out.println("Konnte platformtextur nicht laden!");
    }
}

    public Platform(double x, double y, double w, double h){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

  void draw() {

    if (texture != null && texture.length > 0 && texture[0].length > 0) {

        int texH = texture.length;
        int texW = texture[0].length;

        int startX = (int)x;
        int startY = (int)y;

        int tilesX = Math.max(1, (int)(w / texW));
        int tilesY = Math.max(1, (int)(h / texH));

        for (int iy = 0; iy < tilesY; iy++) {
            for (int ix = 0; ix < tilesX; ix++) {
                Draw.blendImage(
                    startX + ix * texW,
                    startY + iy * texH,
                    texture,
                    false
                );
            }
        }

    } else {
        Draw.setColor(255, 0, 0); // debug
        Draw.filledRect((int)x, (int)y, (int)w, (int)h);
    }
}


        public void update(double deltaTime) {
        // normale Plattform: tut nichts
        } 
    
}
