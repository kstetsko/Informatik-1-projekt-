public class Player {

    // Position und Größe
    double x, y, w, h;
    // Geschwindigkeit
    double vx, vy;

    // Boden-Status (wird von der Kollisionslogik im Game gesetzt)
    boolean onGround = false;
    boolean wasOnGround = false;

    // Respawn-Position
    final double spawnX;
    final double spawnY;

    boolean needsRespawn = false;

    // Input-Konfiguration
    private final boolean isPlayer1;
    private final int keyLeft;
    private final int keyRight;
    private final int keyJump;

    // ───────────────── Animation ─────────────────

    // Animations-Zustände
    private enum AnimState {
        IDLE,
        RUN,
        JUMP
    }

    // Separate Frame-Sets
    private int[][][] idleFrames; // z.B. "idle_01.png"
    private int[][][] runFrames;  // z.B. "run_01.png"
    private int[][][] jumpFrames; // z.B. "jump_01.png"

    // Aktuell aktive Frames (zeigen immer auf eines der oberen Arrays)
    private int[][][] frames;
    private AnimState currentState = AnimState.IDLE;

    // Frame-Zähler
    private int currentFrame = 0;
    private long lastFrameTime = 0;
    private int frameDelay = 25; // ms pro Frame (~40 FPS)

    // Richtung
    private boolean facingLeft = false;

    // Ordner, in dem alle Animations-PNGs liegen
    private String framesFolder;

    public Player(double x, double y, double w, double h,
                  int left, int right, int jump,
                  boolean isPlayer1) {

        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;

        this.spawnX = x;
        this.spawnY = y;

        this.isPlayer1 = isPlayer1;
        this.keyLeft = left;
        this.keyRight = right;
        this.keyJump = jump;

        // Hier kannst du für Player 1 / Player 2 unterschiedliche Ordner nehmen
        // In jedem Ordner liegen dann alle PNGs (idle, run, jump) gemischt.
        this.framesFolder = isPlayer1 ? "boy_running_frames" : "girl_running_frames";

        loadFrames();
    }

    public boolean isPlayer1() {
        return isPlayer1;
    }

    // Lädt alle PNGs aus framesFolder und sortiert sie anhand des Dateinamens
    // in idle/run/jump-Listen. Die Zuordnung passiert über Substrings:
    //  - Name enthält "jump"  -> Jump-Frames
    //  - Name enthält "idle" oder "stand" -> Idle-Frames
    //  - alles andere -> Run-Frames
    private void loadFrames() {
        java.io.File folder = new java.io.File(framesFolder);
        System.out.println("Suche Bilder in: " + folder.getAbsolutePath());

        java.io.File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".png"));

        if (files == null || files.length == 0) {
            System.out.println("Keine PNG-Bilder im Ordner gefunden!");
            idleFrames = runFrames = jumpFrames = null;
            frames = null;
            return;
        }

        java.util.Arrays.sort(files);

        java.util.List<int[][]> idleList = new java.util.ArrayList<>();
        java.util.List<int[][]> runList  = new java.util.ArrayList<>();
        java.util.List<int[][]> jumpList = new java.util.ArrayList<>();

        for (java.io.File f : files) {
            String nameLower = f.getName().toLowerCase();
            int[][] img = Draw.loadImage(folder.getPath() + "/" + f.getName());
            System.out.println("Geladen: " + f.getName());

            if (nameLower.contains("jump")) {
                jumpList.add(img);
            } else if (nameLower.contains("idle") || nameLower.contains("stand")) {
                idleList.add(img);
            } else {
                runList.add(img);
            }
        }

        idleFrames = idleList.isEmpty() ? null : idleList.toArray(new int[idleList.size()][][]);
        runFrames  = runList.isEmpty()  ? null : runList.toArray(new int[runList.size()][][]);
        jumpFrames = jumpList.isEmpty() ? null : jumpList.toArray(new int[jumpList.size()][][]);

        // Default-State festlegen (Reihenfolge der Fallbacks)
        if (idleFrames != null && idleFrames.length > 0) {
            frames = idleFrames;
            currentState = AnimState.IDLE;
        } else if (runFrames != null && runFrames.length > 0) {
            frames = runFrames;
            currentState = AnimState.RUN;
        } else if (jumpFrames != null && jumpFrames.length > 0) {
            frames = jumpFrames;
            currentState = AnimState.JUMP;
        } else {
            frames = null;
        }

        currentFrame = 0;
        lastFrameTime = System.currentTimeMillis();

        System.out.println("Idle-Frames: " + (idleFrames == null ? 0 : idleFrames.length));
        System.out.println("Run-Frames : " + (runFrames == null ? 0 : runFrames.length));
        System.out.println("Jump-Frames: " + (jumpFrames == null ? 0 : jumpFrames.length));
    }

    // Kannst du von außen aufrufen, wenn der Spieler sterben soll
    public void requestRespawn() {
        needsRespawn = true;
    }

    public void respawn() {
        x = spawnX;
        y = spawnY;
        vx = 0;
        vy = 0;
        onGround = false;
        wasOnGround = false;
        needsRespawn = false;
        currentFrame = 0;
        currentState = AnimState.IDLE;
        frames = (idleFrames != null) ? idleFrames : (runFrames != null ? runFrames : jumpFrames);
    }

    // Wird pro Frame vor der Physik/Kollision aufgerufen
    public void handleInput() {
        if (Draw.isKeyDown(keyLeft)) {
            vx = -300;
        } else if (Draw.isKeyDown(keyRight)) {
            vx = 300;
        } else {
            vx = 0;
        }

        if (Draw.isKeyDown(keyJump) && onGround) {
            vy = -700;
        }
    }

    // Physik + Animations-Update
    public void update(double dt) {
    // Physik
    vy += 2000 * dt;
    x += vx * dt;
    y += vy * dt;

    // Blickrichtung
    if (vx < 0) {
        facingLeft = true;
    } else if (vx > 0) {
        facingLeft = false;
    }

    // Zustand bestimmen
    boolean movingHorizontally = Math.abs(vx) > 0.1; // kleiner Toleranzwert
    boolean inAir = !onGround;

    AnimState newState;

    if (inAir && jumpFrames != null && jumpFrames.length > 0) {
        // In der Luft -> Jump
        newState = AnimState.JUMP;
    } else if (movingHorizontally && onGround && runFrames != null && runFrames.length > 0) {
        // Am Boden + bewegt -> Run
        newState = AnimState.RUN;
    } else if (idleFrames != null && idleFrames.length > 0) {
        // Steht -> Idle
        newState = AnimState.IDLE;
    } else if (runFrames != null && runFrames.length > 0) {
        newState = AnimState.RUN;
    } else if (jumpFrames != null && jumpFrames.length > 0) {
        newState = AnimState.JUMP;
    } else {
        newState = null;
    }

    updateAnimationState(newState);
}


    // Dies kannst du z.B. nach der Kollisionsberechnung vom Game aus aufrufen,
    // um Landing-Sounds, Partikel, etc. zu erkennen.
    public void updateGroundState() {
        wasOnGround = onGround;
    }

    public boolean justLanded() {
        return !wasOnGround && onGround;
    }

    // Animations-State wechseln + Frames weiterschalten
    private void updateAnimationState(AnimState newState) {
    if (newState == null) {
        frames = null;
        return;
    }

    // State-Wechsel?
    if (newState != currentState) {
        currentState = newState;

        switch (currentState) {
            case IDLE:
                frames = idleFrames;
                break;
            case RUN:
                frames = runFrames;
                break;
            case JUMP:
                frames = jumpFrames;
                break;
        }

        // Beim State-Wechsel immer beim ersten Frame starten
        currentFrame = 0;
        lastFrameTime = System.currentTimeMillis();
    }

    if (frames == null || frames.length == 0) {
        return;
    }

    long now = System.currentTimeMillis();
    if (now - lastFrameTime > frameDelay) {

        switch (currentState) {
            case IDLE:
                // Idle NICHT animieren → immer Frame 0
                currentFrame = 0;
                break;

            case RUN:
                // Run loopen wie gewohnt
                currentFrame = (currentFrame + 1) % frames.length;
                break;

            case JUMP:
                // Jump EINMAL durchspielen, dann auf letztem Frame bleiben
                if (currentFrame < frames.length - 1) {
                    currentFrame++;
                }
                // kein Modulo → kein Loop
                break;
        }

        lastFrameTime = now;
    }
}


    // Zeichnen
    public void draw() {
        if (frames == null || frames.length == 0) {
            // Fallback: kleines Debug-Rechteck
            Draw.setColor(255, 0, 0);
            Draw.filledRect((int)x, (int)y, (int)w, (int)h);
            return;
        }

        int sx = (int)x;
        int sy = (int)y;

        // Screen bounds check (optional, falls dein Projekt 1000x1000 ist)
        if (sx + w < 0 || sx >= 1000 || sy + h < 0 || sy >= 1000) {
            return;
        }

        Draw.blendImage(sx, sy, frames[currentFrame], facingLeft);
    }
}
