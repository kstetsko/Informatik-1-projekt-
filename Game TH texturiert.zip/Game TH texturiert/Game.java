import java.awt.event.KeyEvent;
import java.io.File;
import javax.sound.sampled.Clip;


public class Game {

    // ---------- Resource helpers ---------- (KI Generiert)
    private static String res(String relativePath) {
        String[] bases = { ".", "..", "../.." };
        for (String base : bases) {
            File f = base.equals(".") ? new File(relativePath) : new File(base, relativePath);
            if (f.exists()) return f.getPath();
        }
        System.out.println("NOT FOUND: " + relativePath + " (user.dir=" + System.getProperty("user.dir") + ")");
        return relativePath;
    }
    private static int[][] safeLoadImage(String relativePath) {
        String p = res(relativePath);
        if (!new File(p).exists()) {
            System.out.println("ERROR: Image not found: " + p);
            return null;
        }
        return Draw.loadImage(p);
    }

    private static Clip safeLoadSound(String relativePath) {
        String p = res(relativePath);
        if (!new File(p).exists()) {
            System.out.println("ERROR: Sound not found: " + p);
            return null;
        }
        return Draw.loadSound(p);
    }

    /**
     * Simple tiling: repeats the given image to cover the rectangle.
     * (No scaling, and the last tile may overflow a bit; that's fine for a platform texture.)
     */
    private static void drawTiled(int x, int y, int w, int h, int[][] img) {
        if (img == null) return;
        int tileW = img[0].length;
        int tileH = img.length;
        for (int yy = y; yy < y + h; yy += tileH) {
            for (int xx = x; xx < x + w; xx += tileW) {
                Draw.blendImage(xx, yy, img, false);
            }
        }
    }

    // ---------- Collision helpers ----------

    public static boolean intersects(Player p, Platform pl) {
        return p.x < pl.x + pl.w &&
               p.x + p.w > pl.x &&
               p.y < pl.y + pl.h &&
               p.y + p.h > pl.y;
    }

    public static boolean victoryCondition(Player p, Door d) {
        return p.x >= d.x &&
               p.x + p.w <= d.x + d.w &&
               p.y >= d.y &&
               p.y + p.h <= d.y + d.h;
    }

    // ---------- Main ----------

    public static void main(String[] args) {

        final int WIDTH = 1000;
        final int HEIGHT = 1000;

        Draw.init(WIDTH, HEIGHT);
        Draw.enableDoubleBuffering(true);  

        // ---------- Players ----------
        Player player1 = new Player(
                100, 860, 40, 40,
                KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT, KeyEvent.VK_UP,
                true
        );

        Player player2 = new Player(
                150, 860, 40, 40,
                65, 68, 87,
                false
        );

        Player[] players = { player1, player2 };

        // ---------- Platforms ----------
        //Platform platform1 = new Platform(50, 900, 900, 50);
        //Platform platformWallRight = new Platform(1, 1 , 50, 950) ;
        //Platform platformWallLeft = new Platform(900, 1 , 50, 950) ;
        Platform platform2 = new Platform(800, 800, 200, 50);
        Platform platform3 = new Platform(50, 700, 630, 50);
        Platform platform4 = new Platform(250, 350, 650, 50);


        
        MovingPlattform movingPlattform =
                new MovingPlattform(50, 350, 180, 40,
                        650, 150,
                        300, 650, 50, 30,     
                        300, 300, 50, 30); 

        Platform[] platforms = {
                platform2, platform3, platform4, movingPlattform
        };

        // ---------- Doors ----------
        Door door1 = new Door(750, 280, 48, 64);
        Door door2 = new Door(650, 280, 48, 64);

        // ---------- Liquids ----------
        Liquid[] liquids = {
                new Water(200, 950, 140, 25),
                new Lava(500, 950, 140, 25),
                new Acid(400, 685, 140, 25)
        };

        // ---------- Pushable Boxes ----------
         PushableBox box1 = new PushableBox(400, 750);
        // PushableBox box2 = new PushableBox(600, 750);
        // PushableBox box3 = new PushableBox(500, 650);
        
         PushableBox[] boxes = { box1, };

        // ---------- Textures ----------
        System.out.println("Working directory (user.dir): " + System.getProperty("user.dir"));

        int[][] bgImg = safeLoadImage("assets/background.png");
        int[][] groundImg = safeLoadImage("assets/dirt_floor.png");
        int[][] platformImg = safeLoadImage("assets/wooden_tiles.png"); // exists in your project
        int[][] door1Img = safeLoadImage("assets/door_green.png");
        int[][] door2Img = safeLoadImage("assets/door_yellow.png");
        int[][] liquidyellow = safeLoadImage("assets/liquid_yellow.png");
        int[][] liquidgreen = safeLoadImage("assets/liquid_green.png");
        int[][] spikes = safeLoadImage("assets/spikes.png");
        
        // ---------- Sounds ----------
        Clip jumpSound = safeLoadSound("sounds game/sfx/Dirt Jump.wav");
        Clip landSound = safeLoadSound("sounds game/sfx/Dirt Land.wav");
        Clip soundtrack = safeLoadSound("sounds game/soundtrack/Piano Pack - Track 03.wav");

if (soundtrack == null) {
    System.out.println("ERROR: Soundtrack not loaded");
} else {
    soundtrack.setFramePosition(0);
    soundtrack.loop(Clip.LOOP_CONTINUOUSLY);
    soundtrack.start();
    System.out.println("OK: Soundtrack playing");
}

        // ---------- Timing ----------
        double lastTime = System.nanoTime() / 1e9;

        // ================= GAME LOOP =================
        while (true) {

            double now = System.nanoTime() / 1e9;
            double dt = now - lastTime;
            lastTime = now;
// ---------- UPDATE ----------
            for (Player p : players) {
                p.handleInput();
                p.update(dt);
                p.onGround = false;
            }

            // ---------- UPDATE BOXES ----------
            for (PushableBox box : boxes) {
                box.update(dt);
            }

            // ---------- MOVING PLATFORMS ----------
            for (Platform pl : platforms) {
                if (pl instanceof MovingPlattform) {
                    MovingPlattform mp = (MovingPlattform) pl;
                    mp.resetTriggers();  
                    for (Player p : players) {
                        mp.checkTrigger(p);  
                    }
                    mp.update(dt);
                }
            }

            // ---------- LIQUIDS ----------
            for (Player p : players) {
                for (Liquid l : liquids) {
                    l.handlePlayer(p);
                }
            }

            // ---------- COLLISIONS ----------
            for (Player p : players) {
                for (Platform pl : platforms) {

                    if (!intersects(p, pl)) continue;

                    double overlapX =
                            Math.min(p.x + p.w, pl.x + pl.w)
                                    - Math.max(p.x, pl.x);

                    double overlapY =
                            Math.min(p.y + p.h, pl.y + pl.h)
                                    - Math.max(p.y, pl.y);

                    if (overlapX <= 0 || overlapY <= 0) continue;

                    if (overlapX < overlapY) {
                        // horizontal
                        p.x += (p.x < pl.x) ? -overlapX : overlapX;
                        p.vx = 0;
                    } else {
                        // vertical
                        if (p.y < pl.y) {
                            p.y = pl.y - p.h;
                            p.vy = 0;
                            p.onGround = true;

                            if (p.justLanded() && landSound != null) {
                                Draw.playSound(landSound);
                            }

                        } else {
                            p.y = pl.y + pl.h;
                            p.vy = 0;
                        }
                    }
                }
                // Floor and Walls Kollisionen
                int floorY = 950; // HÖHE DES BODENS
                if (p.y + p.h > floorY) {
                    p.y = floorY - p.h; // auf den Boden stellen
                    if (p.vy > 0) {
                        p.vy = 0;
                    }
                    p.onGround = true;

                } 
                // 3. Level-Begrenzung links/rechts

                int leftBound = 0;
                int rightBound = WIDTH; // width = 1000

                // linke Wand
                if (p.x < leftBound) {
                    p.x = leftBound;
                    if (p.vx < 0)
                        p.vx = 0;
                }

                // rechte Wand
                if (p.x + p.w > rightBound) {
                    p.x = rightBound - p.w;
                    if (p.vx > 0)
                        p.vx = 0;
                }
                

                // jump sound
                if (!p.onGround && p.wasOnGround && p.vy < 0) {
                    if (jumpSound != null) {
                        Draw.playSound(jumpSound);
                    }
                }

                // ---------- PLAYER-BOX COLLISIONS ----------
                for (PushableBox box : boxes) {
                    if (!PushableBox.intersects(box, p)) continue;

                    double overlapX = Math.min(p.x + p.w, box.x + box.w) - Math.max(p.x, box.x);
                    double overlapY = Math.min(p.y + p.h, box.y + box.h) - Math.max(p.y, box.y);

                    if (overlapX <= 0 || overlapY <= 0) continue;

                    if (overlapX < overlapY) {
                        // horizontal collision
                        if (p.x < box.x) {
                            p.x -= overlapX;
                            box.pushBox(p);
                        } else {
                            p.x += overlapX;
                            box.pushBox(p);
                        }
                        p.vx = 0;
                    } else {
                        // vertical collision
                        if (p.y < box.y) {
                            p.y = box.y - p.h;
                            p.vy = 0;
                            p.onGround = true;
                        } else {
                            p.y = box.y + box.h;
                            p.vy = 0;
                        }
                    }
                }

                // p.updateGroundState();
            }

            // === RESPAWN ===
for (Player p : players) {
    if (p.needsRespawn) {
        p.respawn();
    }
}

// === STATE UPDATE ===
for (Player p : players) {
    p.updateGroundState();
}

            // ---------- BOX-PLATFORM COLLISIONS ----------
            for (PushableBox box : boxes) {
                box.onGround = false;

                for (Platform pl : platforms) {
                    if (!PushableBox.intersects(box, pl)) continue;

                    double overlapX = Math.min(box.x + box.w, pl.x + pl.w) - Math.max(box.x, pl.x);
                    double overlapY = Math.min(box.y + box.h, pl.y + pl.h) - Math.max(box.y, pl.y);

                    if (overlapX <= 0 || overlapY <= 0) continue;

                    if (overlapX < overlapY) {
                        // horizontal collision
                        if (box.x < pl.x) {
                            box.x -= overlapX;
                        } else {
                            box.x += overlapX;
                        }
                        box.vx = 0;
                    } else {
                        // vertical collision
                        if (box.y < pl.y) {
                            box.y = pl.y - box.h;
                            box.vy = 0;
                            box.onGround = true;
                        } else {
                            box.y = pl.y + box.h;
                            box.vy = 0;
                        }
                    }
                }

                // ---------- BOX-BOX COLLISIONS ----------
                for (PushableBox other : boxes) {
                    if (box == other) continue;
                    if (!PushableBox.intersects(box, other)) continue;

                    double overlapX = Math.min(box.x + box.w, other.x + other.w) - Math.max(box.x, other.x);
                    double overlapY = Math.min(box.y + box.h, other.y + other.h) - Math.max(box.y, other.y);

                    if (overlapX <= 0 || overlapY <= 0) continue;

                    if (overlapX < overlapY) {
                        // horizontal collision
                        if (box.x < other.x) {
                            box.x -= overlapX;
                        } else {
                            box.x += overlapX;
                        }
                        box.vx = 0;
                    }
                }
                int floorY = 950;
                if (box.y + box.h > floorY) {
                    box.y = floorY - box.h; // auf den Boden stellen
                    if (box.vy > 0) {
                        box.vy = 0;
                    }
                    box.onGround = true;

                } 
            }            
            // ---------- VICTORY ----------
            if (victoryCondition(player1, door1)
                    && victoryCondition(player2, door2)) {

                Draw.clearScreen();
                Draw.setColor(0, 0, 0);
                Draw.text(400, 500, "VICTORY!", 50);
                Draw.syncToFrameRate();
                return;
            }

            // ---------- DRAW ----------
            Draw.clearScreen();

            // Background (texture if available)
            if (bgImg != null) {
                Draw.blendImage(0, 0, bgImg, false);
            } else {
                Draw.setColor(100, 150, 200);
                Draw.filledRect(0, 0, WIDTH, HEIGHT);
            }

            // Platforms (texture if available)
            if (platformImg != null) {
                for (Platform pl : platforms) {
                    drawTiled((int) pl.x, (int) pl.y, (int) pl.w, (int) pl.h, platformImg);
                }
            } else {
                Draw.setColor(150, 150, 150);
                for (Platform pl : platforms) pl.draw();
            }

            // Draw boxes
            Draw.setColor(139, 90, 43);
            for (PushableBox box : boxes) box.draw();

            for (Liquid l : liquids) {

    int[][] img = null;

    if (l instanceof Water) img = liquidgreen;   // z.B. grün
    if (l instanceof Lava)  img = liquidyellow;  // z.B. gelb
    if (l instanceof Acid)  img = spikes;   // oder eigenes acidImg wenn du eins hast

    if (img != null) {
        // Kacheln oder einfach 1x zeichnen – je nachdem wie deine Liquid-Flächen gedacht sind:
        drawTiled((int)l.x, (int)l.y, (int)l.w, (int)l.h, img);
        // oder: Draw.blendImage((int)l.x, (int)l.y, img, false);
    } else {
        l.draw(); // fallback
    }
}
            // Draw players with their sprites
            player1.draw();
            player2.draw();

           // Draw doors (mit Texturen)
if (door1Img != null) {
    Draw.blendImage((int)door1.x, (int)door1.y, door1Img, false);
} else {
    Draw.setColor(0, 0, 255);
    door1.draw();
}

if (door2Img != null) {
    Draw.blendImage((int)door2.x, (int)door2.y, door2Img, false);
} else {
    Draw.setColor(0, 255, 0);
    door2.draw();
}


        Draw.syncToFrameRate();

        //     try {
        //         Thread.sleep(16);
        //     } catch (InterruptedException ignored) {}
        
}
    }
}
