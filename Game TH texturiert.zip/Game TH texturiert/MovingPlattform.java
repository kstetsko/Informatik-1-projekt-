public class MovingPlattform extends Platform{
    private double startY;
    private double endY;
    private double speed;
    private boolean movingDown = true;

    private double triggerX;
    private double triggerY;
    private double triggerW;
    private double triggerH;
    
    private double trigger2X;
    private double trigger2Y;
    private double trigger2W;
    private double trigger2H;
    private boolean hasTrigger2 = false;
    
    public boolean active = false;
    
    private boolean trigger1Active = false;
    private boolean trigger2Active = false;

    public MovingPlattform(double x, double y, double w, double h,
                          double endY, double speed, double triggerX, double triggerY,
                          double triggerW, double triggerH) {
        super(x, y, w, h);
        this.startY = y;
        this.endY = endY;
        this.speed = speed;
        this.triggerX = triggerX;
        this.triggerY = triggerY;
        this.triggerW = triggerW;
        this.triggerH = triggerH;
        this.hasTrigger2 = false;
    }
    
    public MovingPlattform(double x, double y, double w, double h,
                          double endY, double speed, 
                          double triggerX, double triggerY, double triggerW, double triggerH,
                          double trigger2X, double trigger2Y, double trigger2W, double trigger2H) {
        super(x, y, w, h);
        this.startY = y;
        this.endY = endY;
        this.speed = speed;
        this.triggerX = triggerX;
        this.triggerY = triggerY;
        this.triggerW = triggerW;
        this.triggerH = triggerH;
        this.trigger2X = trigger2X;
        this.trigger2Y = trigger2Y;
        this.trigger2W = trigger2W;
        this.trigger2H = trigger2H;
        this.hasTrigger2 = true;
    }
    
    public void checkTrigger(Player p) {

        boolean inside1 =
            p.x < triggerX + triggerW &&
            p.x + p.w > triggerX &&
            p.y < triggerY + triggerH &&
            p.y + p.h > triggerY;

        if (inside1) {
            trigger1Active = true;
        }
        
        
        if (hasTrigger2) {
            boolean inside2 =
                p.x < trigger2X + trigger2W &&
                p.x + p.w > trigger2X &&
                p.y < trigger2Y + trigger2H &&
                p.y + p.h > trigger2Y;
            
            if (inside2) {
                trigger2Active = true;
            }
        }
        
        active = trigger1Active || trigger2Active;
    }
    
    public void resetTriggers() {
        trigger1Active = false;
        trigger2Active = false;
    }

@Override
    void draw() {
        super.draw();   // Plattform normal zeichnen

        // DEBUG: Erstes Trigger anzeigen
        Draw.setColor(255, 0, 100);
        Draw.filledRect(
            (int) triggerX,
            (int) triggerY,
            (int) triggerW,
            (int) triggerH
        );
        
        // DEBUG: Zweites Trigger anzeigen (wenn vorhanden)
        if (hasTrigger2) {
            Draw.setColor(0, 255, 100);
            Draw.filledRect(
                (int) trigger2X,
                (int) trigger2Y,
                (int) trigger2W,
                (int) trigger2H
            );
        }
    }

    public void update(double deltaTime) {
        if (!active) return;
        
        if (movingDown) {
            y += speed * deltaTime;
            if (y >= endY) {
                y = endY;
                movingDown = false;
            }
        } else {
            y -= speed * deltaTime;
            if (y <= startY) {
                y = startY;
                movingDown = true;
            }
        }
    }
}

